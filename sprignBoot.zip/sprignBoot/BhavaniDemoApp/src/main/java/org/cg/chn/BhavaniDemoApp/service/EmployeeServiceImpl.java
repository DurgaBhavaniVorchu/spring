package org.cg.chn.BhavaniDemoApp.service;

import java.util.List;

import org.cg.chn.BhavaniDemoApp.bean.Employee;
import org.cg.chn.BhavaniDemoApp.dao.EmployeeRepository;
import org.cg.chn.BhavaniDemoApp.exception.EmployeeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository employeeRepository;
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			// TODO Auto-generated method stub
			return employeeRepository.findAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
    public List<Employee> addEmployee(Employee emp) throws EmployeeException {
        if(employeeRepository.existsById(emp.getId())) {
            throw new EmployeeException("Employee with id"+emp.getId()+"already exits");
        }
        employeeRepository.save(emp);
        return getAllEmployees();
       
    }

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		/*Optional<Employee> o = employeeRepository.findById(id);
		if(!o.isPresent()) {
			throw new EmployeeException("Employee with Id"+id+" does not exist");
		}*/
		
		
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id "+id+" does not exist");
		}
		return employeeRepository.findById(id).get();
	}

	@Override
    public List<Employee> deleteEmployee(int id) throws EmployeeException {
        if (!employeeRepository.existsById(id)) {

 

            throw new EmployeeException("Employee with id" + id + "does not exits");
        }
        employeeRepository.deleteById(id);
        return getAllEmployees();
    }

	@Override
	public List<Employee> updateEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
