package org.cg.chn.BhavaniDemoApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BhavaniDemoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BhavaniDemoAppApplication.class, args);
	}

}
