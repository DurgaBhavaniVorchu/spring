package org.cg.chn.BhavaniDemoApp.service;

import org.cg.chn.BhavaniDemoApp.bean.Employee;
import org.cg.chn.BhavaniDemoApp.exception.EmployeeException;


import java.util.*;

public interface EmployeeService {
	List<Employee> getAllEmployees() throws EmployeeException;
	List<Employee> addEmployee(Employee emp) throws EmployeeException;
	Employee getEmployeeById(int id) throws EmployeeException;
	List<Employee> deleteEmployee(int id) throws EmployeeException;
	List<Employee> updateEmployee(int id) throws EmployeeException;
}
